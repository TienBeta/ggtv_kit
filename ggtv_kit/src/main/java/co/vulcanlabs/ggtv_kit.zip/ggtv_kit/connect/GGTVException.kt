package co.vulcanlabs.ggtv_kit.connect

/**
 * Custom exceptions for GGTV operations
 */
sealed class GGTVException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class NotInitializedException : GGTVException("GGTV chưa được khởi tạo. Gọi init() trước.")
    class NotConnectedException : GGTVException("Chưa kết nối đến TV. Gọi connect() trước.")
    class ConnectTimeoutException : GGTVException("Timeout exception.")
    class ConnectionFailedException(message: String, cause: Throwable? = null) : GGTVException("Kết nối thất bại: $message", cause)
    class PairingRequiredException : GGTVException("Yêu cầu pairing với TV")
    class PairingFailedException(message: String) : GGTVException("Pairing thất bại: $message")
    class CommandFailedException(command: String, cause: Throwable? = null) : GGTVException("Lệnh '$command' thất bại", cause)
    class PythonException(message: String, cause: Throwable? = null) : GGTVException("Python error: $message", cause)
}
