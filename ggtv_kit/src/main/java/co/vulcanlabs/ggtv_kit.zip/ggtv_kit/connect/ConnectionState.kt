package co.vulcanlabs.ggtv_kit.connect

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Represents the connection state of GGTV
 */
sealed interface ConnectionState : Parcelable {
    @Parcelize
    object Disconnected : ConnectionState

    @Parcelize
    object Connecting : ConnectionState

    @Parcelize
    data class Connected(val deviceInfo: GGTVDevice? = null) : ConnectionState

    @Parcelize
    object PairingRequired : ConnectionState
    @Parcelize
    object PairingFailed : ConnectionState

    @Parcelize
    data class Error(val message: String) : ConnectionState
}
