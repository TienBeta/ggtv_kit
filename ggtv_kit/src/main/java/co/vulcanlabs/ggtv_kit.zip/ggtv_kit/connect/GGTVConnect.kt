package co.vulcanlabs.ggtv_kit.connect

import android.content.Context
import androidx.annotation.MainThread
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.lifecycleScope
import co.vulcanlabs.ggtv_kit.GGTVConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber
import kotlin.also
import kotlin.collections.forEach
import kotlin.fold
import kotlin.getOrThrow
import kotlin.let
import kotlin.text.toRegex

/**
 * Main GGTV Manager class
 * Thread-safe singleton with lifecycle awareness
 */

class GGTVConnect private constructor(
    private val config: GGTVConfig = GGTVConfig.Companion.DEFAULT
) : DefaultLifecycleObserver {
    private val libraryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    companion object {
        @Volatile
        private var INSTANCE: GGTVConnect? = null

        @MainThread
        fun getInstance(config: GGTVConfig = GGTVConfig.Companion.DEFAULT): GGTVConnect {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: GGTVConnect(config).also {
                    INSTANCE = it
                    ProcessLifecycleOwner.get().lifecycle.addObserver(it)
                    if (config.enableLogging && Timber.treeCount <= 0) {
                        Timber.plant(Timber.DebugTree())
                    }
                }
            }
        }

        /**
         * For testing purposes
         */
        internal fun resetInstance() {
            INSTANCE = null
        }
    }

    private val pythonManager = PythonManager()
    private val managerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Connection state flow
    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private var currentIpAddress: String? = null

    /**
     * Initialize GGTV với Android context
     * Thread-safe và idempotent
     */
    suspend fun init(context: Context): GGTVResult<Unit> =
        withContext(Dispatchers.IO) {
            withTimeoutOrNull(config.connectionTimeoutMs) {
                pythonManager.initialize(context)
                    .fold(
                        onSuccess = {
                            Timber.i("GGTV initialized successfully")
                            GGTVResult.success(Unit)
                        },
                        onFailure = {
                            Timber.e(it, "GGTV initialization failed")
                            GGTVResult.error(GGTVException.PythonException("init failed"))
                        }
                    )
            } ?: GGTVResult.error(GGTVException.ConnectTimeoutException())
        }


    /**
     * Connect to Android TV with automatic retry
     */
    fun connect(ipAddress: String, onResult: ((GGTVResult<GGTVDevice>) -> Unit)? = null) {
        if (!pythonManager.isInitialized()) {
            onResult?.invoke(GGTVResult.error(GGTVException.NotInitializedException()))
        }
        _connectionState.value = ConnectionState.Connecting
        currentIpAddress = ipAddress

        libraryScope.launch {
            try {
//                withTimeout(config.connectionTimeoutMs) {
                pythonManager.executeCommand("connect_to_tv", ipAddress)
                    .fold(
                        onSuccess = { pyResult ->
                            when {
                                (pyResult as? Boolean) == true -> {
                                    val deviceInfo = getDeviceInfoInternal()
                                    if (deviceInfo != null) {
                                        val connectedState = ConnectionState.Connected(deviceInfo)
                                        _connectionState.value = connectedState
                                        onResult?.invoke(GGTVResult.success(deviceInfo))
                                    } else {
                                        val message = "Can not get Device Info"
                                        _connectionState.value = ConnectionState.Error(message)
                                        onResult?.invoke(
                                            GGTVResult.error(
                                                GGTVException.ConnectionFailedException(
                                                    message
                                                )
                                            )
                                        )
                                    }
                                }

                                else -> {
                                    val message = "Unknown error !"
                                    _connectionState.value = ConnectionState.Error(message)
                                    onResult?.invoke(
                                        GGTVResult.error(
                                            GGTVException.ConnectionFailedException(
                                                message
                                            )
                                        )
                                    )
                                }
                            }
                        },
                        onFailure = { exception ->
                            when (exception) {
                                is GGTVException.PairingRequiredException -> {
                                    val pairingState = ConnectionState.PairingRequired
                                    _connectionState.value = pairingState
                                    onResult?.invoke(
                                        GGTVResult.error(
                                            GGTVException.PairingRequiredException()
                                        )
                                    )
                                }

                                else -> {
                                    val exception =
                                        GGTVException.ConnectionFailedException(
                                            "Unexpected error: ${exception.message}",
                                            exception
                                        )
                                    val errorState = ConnectionState.Error(
                                        exception.message ?: "Connection failed"
                                    )
                                    _connectionState.value = errorState
                                    onResult?.invoke(
                                        GGTVResult.error(exception)
                                    )
                                }
                            }
                        }
                    )
            } catch (e: TimeoutCancellationException) {
                val exception = GGTVException.ConnectionFailedException("Connection timeout", e)
                val errorState = ConnectionState.Error(exception.message ?: "Connection failed")
                _connectionState.value = errorState
                onResult?.invoke(
                    GGTVResult.error(
                        exception
                    )
                )
            }
        }

    }


    /**
     * Complete pairing process
     */
    suspend fun completePairing(pairingCode: String): GGTVResult<Boolean> {
        if (!pythonManager.isInitialized()) {
            return GGTVResult.error(GGTVException.NotInitializedException())
        }

        return try {
            withTimeout(config.connectionTimeoutMs) {
                // Finish pairing
                val pairingResult =
                    pythonManager.executeCommand("finish_pairing", pairingCode)
                        .getOrThrow()

                if ((pairingResult as? Boolean) == true) {
                    // Retry connection
                    val connectResult = pythonManager.executeCommand("retry_connection")
                        .getOrThrow()

                    if ((connectResult as? Boolean) == true) {
                        val deviceInfo = getDeviceInfoInternal()
                        val connectedState = ConnectionState.Connected(deviceInfo)
                        _connectionState.value = connectedState
                        Timber.i("Pairing completed successfully")
                        GGTVResult.success(true)
                    } else {
                        val exception =
                            GGTVException.PairingFailedException("Pairing thành công nhưng không thể kết nối")
                        _connectionState.value = ConnectionState.Error(exception.message!!)
                        GGTVResult.error(exception)
                    }
                } else {
                    val exception =
                        GGTVException.PairingFailedException("Mã pairing không đúng")
                    _connectionState.value = ConnectionState.PairingFailed
                    GGTVResult.error(exception)
                }
            }
        } catch (_: TimeoutCancellationException) {
            GGTVResult.error(GGTVException.ConnectTimeoutException())
        } catch (e: GGTVException.PairingFailedException) {
            Timber.e(e, "Pairing failed")
            _connectionState.value = ConnectionState.PairingFailed
            GGTVResult.error(e)
        } catch (e: Exception) {
            Timber.e(e, "Pairing failed")

            val exception =
                GGTVException.PairingFailedException("Lỗi không xác định: ${e.message}")
            _connectionState.value = ConnectionState.Error(exception.message!!)
            GGTVResult.error(exception)
        }
    }


    /**
     * Send key command to TV
     */
    fun sendKey(keyCode: String, onResult: ((GGTVResult<Unit>) -> Unit)? = null) {
        if (_connectionState.value !is ConnectionState.Connected) {
            onResult?.invoke(GGTVResult.error(GGTVException.NotConnectedException()))
        }

        try {
            libraryScope.launch {
                withTimeout(config.commandTimeoutMs) {
                    pythonManager.executeCommand("send_key", keyCode)
                        .fold(
                            onSuccess = {
                                Timber.d("Key sent: $keyCode")
                                onResult?.invoke(GGTVResult.success(Unit))
                            },
                            onFailure = { exception ->
                                val message = "Failed to send key: $keyCode"
                                Timber.e(exception, message)
                                val ggtvException =
                                    GGTVException.CommandFailedException("send_key", exception)
                                onResult?.invoke(GGTVResult.error(ggtvException))
                            }
                        )
                }
            }
        } catch (e: TimeoutCancellationException) {
            onResult?.invoke(GGTVResult.error(GGTVException.ConnectTimeoutException()))
        }
    }

    /**
     * Open app on TV
     */
    fun openApp(appName: String, onResult: ((GGTVResult<Unit>) -> Unit)? = null) {
        if (_connectionState.value !is ConnectionState.Connected) {
            onResult?.invoke(GGTVResult.error(GGTVException.NotConnectedException()))
        }

        try {
            libraryScope.launch {
                withTimeout(config.commandTimeoutMs) {
                    pythonManager.executeCommand("open_app", appName)
                        .fold(
                            onSuccess = {
                                Timber.d("App opened: $appName")
                                onResult?.invoke(GGTVResult.success(Unit))
                            },
                            onFailure = { exception ->
                                val message = "Failed to open app: $appName"
                                Timber.e(exception, message)
                                onResult?.invoke(
                                    GGTVResult.error(
                                        GGTVException.CommandFailedException(
                                            "open_app",
                                            exception
                                        )
                                    )
                                )
                            }
                        )
                }
            }
        } catch (e: TimeoutCancellationException) {
            onResult?.invoke(
                GGTVResult.error(
                    GGTVException.CommandFailedException(
                        "open_app timeout",
                        e
                    )
                )
            )
        }
    }

    /**
     * Get current device information
     */
    suspend fun getDeviceInfo(): GGTVResult<GGTVDevice> {
        if (_connectionState.value !is ConnectionState.Connected) {
            return GGTVResult.error(GGTVException.NotConnectedException())
        }

        val deviceInfo = getDeviceInfoInternal()
        return if (deviceInfo != null) {
            GGTVResult.success(deviceInfo)
        } else {
            GGTVResult.error(GGTVException.CommandFailedException("get_device_info"))
        }
    }

    private suspend fun getDeviceInfoInternal(): GGTVDevice? {
        return try {
            pythonManager.executeCommand("get_device_info")
                .getOrNull()
                ?.toString()
                ?.let { jsonString ->
                    // Parse JSON thành DeviceInfo
                    // Simplified parsing - trong thực tế nên dùng JSON library
                    GGTVDevice(
                        name = extractJsonValue(jsonString, "name"),
                        model = extractJsonValue(jsonString, "model"),
                        version = extractJsonValue(jsonString, "version"),
                        ipAddress = currentIpAddress
                    )
                }
        } catch (e: Exception) {
            Timber.w(e, "Failed to get device info")
            null
        }
    }

    private fun extractJsonValue(json: String, key: String): String? {
        // Simplified JSON parsing - replace with proper JSON library in production
        val regex = "\"$key\"\\s*:\\s*\"([^\"]+)\"".toRegex()
        return regex.find(json)?.groupValues?.get(1)
    }

    /**
     * Disconnect from TV
     */
    fun disconnect() {
        try {
            libraryScope.launch {
                if (_connectionState.value is ConnectionState.Connected) {
                    pythonManager.executeCommand("disconnect_from_tv")
                }

                _connectionState.value = ConnectionState.Disconnected
                currentIpAddress = null
                Timber.i("Disconnected from TV")
            }
        } catch (e: Exception) {
            Timber.e(e, "Disconnect failed")
        } finally {
            libraryScope.cancel()
        }
    }

    /**
     * Cleanup resources
     */
    fun cleanup() {
        return try {
            libraryScope.launch {
                if (_connectionState.value is ConnectionState.Connected) {
                    pythonManager.executeCommand("cleanup")
                }
                _connectionState.value = ConnectionState.Disconnected
                currentIpAddress = null
            }
            Timber.i("GGTV cleaned up")
        } catch (e: Exception) {
            Timber.w(e, "Cleanup encountered errors")
        } finally {
            libraryScope.cancel()
        }
    }

    /**
     * Check if currently connected
     */
    fun isConnected(): Boolean = _connectionState.value is ConnectionState.Connected

    /**
     * Get current IP address
     */
    fun getCurrentIpAddress(): String? = currentIpAddress

    // Lifecycle callbacks
    override fun onStop(owner: LifecycleOwner) {
        managerScope.launch {
            cleanup()
        }
    }

    override fun onDestroy(owner: LifecycleOwner) {
        managerScope.cancel()
        ProcessLifecycleOwner.get().lifecycle.removeObserver(this)
    }
}

/**
 * Observe connection state changes
 */
fun GGTVConnect.observeConnectionState(
    lifecycleOwner: LifecycleOwner,
    onStateChanged: (ConnectionState) -> Unit
) {
    lifecycleOwner.lifecycleScope.launch {
        connectionState.collectLatest { state ->
            onStateChanged(state)
        }
    }
}

/**
 * Send multiple keys in sequence
 */
fun GGTVConnect.sendKeys(
    lifecycleOwner: LifecycleOwner,
    vararg keyCodes: String, delayMs: Long = 100L
) {
    lifecycleOwner.lifecycleScope.launch {
        keyCodes.forEach { keyCode ->
            sendKey(keyCode)
            delay(delayMs)
        }
    }
}